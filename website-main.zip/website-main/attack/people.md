# People


## Principal Investigators
- [Vijay Ganesh](https://vganesh1.github.io/){:target="_blank"}, Georgia Institute of Technology
- [Martin Ochoa](http://dblp.uni-trier.de/pers/hd/o/Ochoa:Mart=iacute=n){:target="_blank"}, Singapore University of Technology and Design
- [Sebastian Banescu](https://www.in.tum.de/i04/banescu/){:target="_blank"}, Quantstamp Inc


## Researchers
- [Gilles Barthe](https://software.imdea.org/people/gilles.barthe/){:target="_blank"}, IMDEA Software
- [Mayank Varia](http://www.mvaria.com/){:target="_blank"}, Boston University
- [Cynthia Disenfeld](https://dblp.org/pid/57/11135.html) , University of Toronto
