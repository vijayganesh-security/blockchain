# People


## Principal Investigators
- [Vijay Ganesh](https://vganesh1.github.io/){:target="_blank"}, Georgia Institute of Technology
- [Anwar Hasan](https://ece.uwaterloo.ca/~ahasan/){:target="_blank"}, University of Waterloo


## Researchers
- [Behkish Nassirzadeh](https://ece.uwaterloo.ca/~bnassirz/){:target="_blank"}, University of Waterloo
- [Stefanos Leonardos](https://www.linkedin.com/in/lnrdpss/?originalSubdomain=ca(https://stefanosleonardos.wordpress.com/)){:target="_blank"}, King’s College London
- [Albert Heinle](https://ca.linkedin.com/in/albertheinle){:target="_blank"}, CoGaurd
- [Sebastian Banescu](https://www.in.tum.de/i04/banescu/){:target="_blank"}, Quantstamp Inc
- [William Zhang](https://www.linkedin.com/in/quan-zhang-william/?originalSubdomain=ca){:target="_blank"}, University of Waterloo
- [Leonardo Pasos](https://www.linkedin.com/in/lnrdpss/?originalSubdomain=ca){:target="_blank"}, Quantstamp Inc
- [Steven Stewart](https://medium.com/@stevenstewart_9009){:target="_blank"}, Quantstamp Inc
- [Huaiying (Jolly) Sun](https://dblp.org/pid/202/4974.html),  Shanghai Institute of Technology
